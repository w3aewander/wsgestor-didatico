<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Minha primeira página em PHP</h1>

    <h2>Operadores Relacionais</h2>
    <?php
        echo (5 == 5) . "<br>";  //igualdade
        //ou  print(5 == 5)
        echo (6 > 5) . "<br>";   //maior que
        echo ( 6 < 5 ) . "<br>"; //menor que
        echo (6 >= 5 ) . "<br>";  //maior ou igual
        echo (6 <= 5 ) . "<br>";  //menor igual
        echo ( 5 != 5 ) . "<br>"; //diferente de 
        //out print ( 5 <> 5)   
    ?>
    <h2>Operadores Lógicos</h2>

</body>
</html>