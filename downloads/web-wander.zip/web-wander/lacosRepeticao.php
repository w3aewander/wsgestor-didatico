<?php
  /* Estruturas de repetição
     ou laços de repetição
     usando a instrução While
  */

  $maximo = 10;
  $x = 1;

//   while ( $x <= $maximo ){
//       echo "Variável X tem valor " . $x;
//       $x++; //$x = $x + 1  
//       echo "<br>";
//   }

  echo "<h2>Laço com a instrução FOR</h2>";
  for($x=1;$x <= 10;$x++){
    echo "Variável X tem valor " . $x;
    echo "<br>";
  }

  

